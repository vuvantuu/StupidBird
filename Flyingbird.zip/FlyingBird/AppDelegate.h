//
//  AppDelegate.h
//  FlyingBird
//
//  Created by Apple on 10/07/2019.
//  Copyright © 2019 tuuvv. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

